package model.selection;

public enum SelectionType {

	TORNEO, RESTOS
}
