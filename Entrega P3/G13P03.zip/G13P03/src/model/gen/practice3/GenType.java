package model.gen.practice3;

public enum GenType {

	GRAMATICA_EVOLUTIVA, PROGRAMACION_EVOLUTIVA;
}
