package model.fitness;

public enum FitnessFunction {

	ADAPTATION;
}
