package model.fitness.practice3;

import model.fitness.Variable;

public class CallbackVariable extends Variable {

	public CallbackVariable(String name) {
		super(name);
	}
}
