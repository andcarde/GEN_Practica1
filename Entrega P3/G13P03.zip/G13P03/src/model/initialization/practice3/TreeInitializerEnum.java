package model.initialization.practice3;

public enum TreeInitializerEnum {

	FULL, GROW, RAMPED_AND_HALP;
}
