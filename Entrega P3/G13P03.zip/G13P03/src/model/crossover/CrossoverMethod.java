package model.crossover;

public enum CrossoverMethod {
	
	CROSSOVER_TREE,
	
	// Affect the binary gene
	ONE_POINT, UNIFORM;
}
