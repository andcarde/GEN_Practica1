package model.initialization.practice3;

import model.chromosome.practice3.TreeChromosome;

public interface TreeInitializer {

	TreeChromosome initialize();
}
