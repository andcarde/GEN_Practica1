package model;

import java.util.HashMap;
import java.util.Map;

import control.Request;
import model.crossover.CrossoverBuilder;
import model.crossover.CrossoverI;
import model.fitness.Fitness;
import model.fitness.FunctionBuilder;
import model.gen.practice3.GenType;
import model.mutation.MutationBuilder;
import model.mutation.MutationI;
import model.random.RandomGenerator;
import model.selection.SelectionBuilder;
import model.selection.SelectionI;

public class Builder {

	private static MoldI mold;
	
	public static Map<String, Object> build(Request request) {
		RandomGenerator.setSeed(request.getSeed());
		
		Map<String, Object> config = new HashMap<>();
		config.put("generation_amount", request.getGenerationAmount());
		config.put("population_amount", request.getPopulationAmount());
		config.put("elitism_amount", request.getElitismProbability());
		MutationI mutation = buildMutation(request, request.getGenType());
		config.put("mutation", mutation);
		mold = buildMold(request, mutation);
		config.put("mold", mold);
		config.put("selection", buildSelection(request));
		config.put("crossover", buildCrossover(request, mold, mold.getFunction().getGenType()));
		config.put("initialization", request.getInitalizationMethod());
		config.put("gen_type", mold.getFunction().getGenType());
		config.put("bloating", mold.getBloating());
		return config;
	}
	
	
	private static MoldI buildMold(Request request, MutationI mutation) {
		int maxHeight = request.getMaxDepth();
		int numWraps = request.getWraps();
		Fitness function = FunctionBuilder.build(request.getFitnessFunction(), request.getGenType());
		return new Mold(function, request.isBloatingActive(), mutation, request.getPopulationAmount(), maxHeight,
				numWraps);
	}
	
	private static SelectionI buildSelection(Request request) {
		return SelectionBuilder.build(request.getSelectionMethod(), request.getTournamentRequest(),
				mold.getFunction().isMaximization(),request.getTruncationAmount());
	}

	private static CrossoverI buildCrossover(Request request, MoldI mold, GenType genType) {
		return CrossoverBuilder.build(request.getCrossoverMethod(),
				request.getCrossoverProbability(), mold, genType);
	}
	
	private static MutationI buildMutation(Request request, GenType gen) {
		return MutationBuilder.build(gen, request.getMutationMethod(), request.getMutationProbability());
	}
}
