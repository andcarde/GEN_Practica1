package model.gen.practice3;

public enum GenType {

	BINARY, TREE;
}
