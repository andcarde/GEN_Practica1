package model.fitness.practice3;

public interface Callback {
	
	double getValue(double xvalue);
}
