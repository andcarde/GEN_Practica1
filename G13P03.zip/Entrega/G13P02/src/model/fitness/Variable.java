package model.fitness;

public class Variable {

	private String name;
	
	public Variable(String name) {
		this.name = name;
	}

	public String getName() {
		return this.name;
	}
}
